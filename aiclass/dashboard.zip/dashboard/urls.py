
from django.urls import path
from . import views

urlpatterns = [
    path('zoom/login/', views.zoom_login, name='zoom_login'),  # start OAuth login
    path('zoom/oauth/callback/', views.zoom_callback, name='zoom_callback'),  # OAuth callback

    path('start-live-class/', views.start_live_class, name='start_live_class'),  # create instant meeting
    path('schedule-meeting/', views.schedule_meeting, name='schedule_meeting'),  # schedule meeting
    path('', views.index, name='index'), 
    path('dashboard/', views.dashboard, name='dashboard'), # dashboard
    path('studentdashboard/', views.student_dashboard, name='studentdashboard'), # dashboard
    path('login/', views.loginpage, name='login'), # dashboard

]
