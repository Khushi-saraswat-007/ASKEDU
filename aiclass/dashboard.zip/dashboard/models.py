
# Create your models here.
from django.db import models
from django.contrib.auth.models import User

class ScheduledMeeting(models.Model):
    topic = models.CharField(max_length=200)
    zoom_meeting_id = models.CharField(max_length=50)
    start_time = models.DateTimeField()
    join_url = models.URLField()
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.topic} at {self.start_time}"
