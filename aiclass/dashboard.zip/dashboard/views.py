import base64
import requests
from requests.auth import HTTPBasicAuth
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils.timezone import now
from .models import ScheduledMeeting

# Zoom OAuth app credentials
CLIENT_ID = 'QtyhvbthQt2ucBAHZ7LIfg'
CLIENT_SECRET = 'Z92VCgYSygTt9XZEYT5AGiESeWUvEwXW'
REDIRECT_URI = 'http://localhost:8000/zoom/oauth/callback/'


def zoom_login(request):
    """Redirect user to Zoom OAuth authorize page"""
    zoom_auth_url = (
        f"https://zoom.us/oauth/authorize?"
        f"response_type=code&client_id={CLIENT_ID}&redirect_uri={REDIRECT_URI}"
    )
    return redirect(zoom_auth_url)


def zoom_callback(request):
    """Handle Zoom OAuth callback and store access token in session"""
    code = request.GET.get('code')
    if not code:
        return render(request, 'error.html', {'message': 'No code received from Zoom.'})

    token_url = "https://zoom.us/oauth/token"
    response = requests.post(
        token_url,
        params={
            'grant_type': 'authorization_code',
            'code': code,
            'redirect_uri': REDIRECT_URI,
        },
        auth=HTTPBasicAuth(CLIENT_ID, CLIENT_SECRET)
    )
    data = response.json()
    print("Zoom Token Response:", data)  # DEBUG print

    access_token = data.get('access_token')
    if access_token:
        request.session['zoom_access_token'] = access_token
        return redirect('dashboard')
    else:
        error_msg = data.get('error_description', 'Failed to get access token from Zoom.')
        return render(request, 'error.html', {'message': error_msg})


@login_required
def start_live_class(request):
    """Create an instant Zoom meeting and redirect user to join URL"""
    access_token = request.session.get('zoom_access_token')
    if not access_token:
        return redirect('zoom_login')

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json',
    }
    meeting_details = {
        "topic": "Live Class",
        "type": 1  # Instant meeting
    }
    response = requests.post(
        'https://api.zoom.us/v2/users/me/meetings',
        headers=headers,
        json=meeting_details
    )
    data = response.json()
    print("Start Live Class Response:", data)  # DEBUG print

    join_url = data.get('join_url')
    if join_url:
        return redirect(join_url)
    else:
        return render(request, 'error.html', {'message': 'Failed to create Zoom meeting.'})


@login_required
def schedule_meeting(request):
    """Schedule a Zoom meeting and save it in database"""
    access_token = request.session.get('zoom_access_token')
    if not access_token:
        return redirect('zoom_login')

    if request.method == 'POST':
        topic = request.POST.get('topic')
        start_time = request.POST.get('start_time')  # Expected format: 'YYYY-MM-DDTHH:MM'

        if not topic or not start_time:
            return render(request, 'schedule_meeting.html', {'error': 'Please fill all fields.'})

        # Zoom expects ISO8601 with seconds and timezone
        start_time_iso = start_time + ":00Z"

        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json',
        }
        meeting_data = {
            "topic": topic,
            "type": 2,  # Scheduled meeting
            "start_time": start_time_iso,
            "duration": 60,
            "timezone": "Asia/Kolkata",
            "settings": {
                "host_video": True,
                "participant_video": True,
                "join_before_host": False,
                "mute_upon_entry": True
            }
        }
        response = requests.post(
            'https://api.zoom.us/v2/users/me/meetings',
            headers=headers,
            json=meeting_data
        )
        data = response.json()
        print("Schedule Meeting Response:", data)  # DEBUG print

        if 'id' in data:
            ScheduledMeeting.objects.create(
                topic=topic,
                zoom_meeting_id=data['id'],
                start_time=start_time,
                join_url=data['join_url'],
                created_by=request.user
            )
            return redirect('dashboard')
        else:
            error_msg = data.get('message', 'Failed to schedule meeting on Zoom.')
            return render(request, 'schedule_meeting.html', {'error': error_msg})

    return render(request, 'schedule_meeting.html')


@login_required
def dashboard(request):
    """Show dashboard with list of meetings and next upcoming meeting"""
    meetings = ScheduledMeeting.objects.filter(start_time__gte=now()).order_by('start_time')
    next_meeting = meetings.first()
    return render(request, 'dashboard.html', {
        'meetings': meetings,
        'next_meeting': next_meeting
    })

def index(request):
    return render(request, 'index.html')
@login_required
def student_dashboard(request):
    """Show dashboard with list of meetings and next upcoming meeting"""
    meetings = ScheduledMeeting.objects.filter(start_time__gte=now()).order_by('start_time')
    next_meeting = meetings.first()
    return render(request, 'testdashboard.html', {
        'meetings': meetings,
        'next_meeting': next_meeting
    })

def loginpage(request):
    """Render the login page"""
    return render(request, 'login1.html')